package com.onlineshopping.user.entity;

public class Profile {

}
