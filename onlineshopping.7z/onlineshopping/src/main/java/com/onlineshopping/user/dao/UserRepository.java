package com.onlineshopping.user.dao;

public class UserRepository {

}
