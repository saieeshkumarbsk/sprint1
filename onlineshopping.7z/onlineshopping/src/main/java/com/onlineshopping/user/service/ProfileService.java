package com.onlineshopping.user.service;

public interface ProfileService {

}
