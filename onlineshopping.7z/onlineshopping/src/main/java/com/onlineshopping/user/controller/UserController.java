package com.onlineshopping.user.controller;

public class UserController {

}
