package com.onlineshopping.user.exception;

public class UserNotFoundException {

}
