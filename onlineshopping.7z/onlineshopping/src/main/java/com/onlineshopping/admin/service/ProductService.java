package com.onlineshopping.admin.service;

public interface ProductService {

}
