package com.onlineshopping.admin.exception;

public class AdminNotFoundException {

}
