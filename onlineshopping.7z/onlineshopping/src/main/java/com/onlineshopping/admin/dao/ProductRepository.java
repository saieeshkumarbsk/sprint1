package com.onlineshopping.admin.dao;

public class ProductRepository {

}
