package com.onlineshopping.admin.controller;

public class AdminController {

}
