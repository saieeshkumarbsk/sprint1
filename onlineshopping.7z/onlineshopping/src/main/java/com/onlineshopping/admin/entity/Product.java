package com.onlineshopping.admin.entity;

public class Product {

}
